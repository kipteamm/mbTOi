//
// Created by PPetre on 30/09/2025.
//

#ifndef CFG_H
#define CFG_H
#include <map>
#include <set>
#include <string>
#include <vector>


class CFG {
public:
    explicit CFG(const std::string& file);

    void print();

private:
    std::set<std::string> variables;
    std::set<std::string> terminals;
    // VARIABLE (HEAD) -> VECTOR OF PARSEABLE STRING(S) (BODY(IES))
    std::map<std::string, std::vector<std::vector<std::string>>> productions;
    std::string startSymbol;
};



#endif //CFG_H
